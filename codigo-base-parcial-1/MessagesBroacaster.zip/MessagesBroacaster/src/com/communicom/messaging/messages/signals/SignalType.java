package com.communicom.messaging.messages.signals;

public enum SignalType {
	MANUAL_DATA,
	AUTOMATIC_DATA,
	PING
}
